// Initialize app
var myApp = new Framework7();


// If we need to use custom DOM library, let's save it to $$ variable:
var $$ = Dom7;

// Add view
var mainView = myApp.addView('.view-main', {
    // Because we want to use dynamic navbar, we need to enable it for this view:
    dynamicNavbar: true
});

// Handle Cordova Device Ready Event
$$(document).on('deviceready', function () {
    console.log("Device is ready!");
});

// adds data to selling card
$(document).ready(function () {
    $.get("backend/get.php", function (data) {
        data = JSON.parse(data);
        myApp.formFromJSON('#get-form', data[0]);
    });
});

// code for add page
myApp.onPageBeforeInit('add', function () {
    $$('#submit').on('click', function () {
        var formData = myApp.formToJSON('#send-form');
        alert(JSON.stringify(formData));
    });
});
