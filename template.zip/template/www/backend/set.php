<?php
include "connection.php";

$produtName = $_GET["productName"];
$phone = $_GET["phone"];
$price = $_GET["price"];
$disc = $_GET["disc"];
echo $produtName;
$sql = "INSERT INTO products (productName, phone, price, discreption)
VALUES ('$produtName', '$phone', '$price', '$disc')";

if ($mysqli->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $mysqli->error;
}
