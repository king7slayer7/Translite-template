
<?php

include "connection.php";

$sql = "SELECT * FROM products WHERE id > (SELECT MAX(id) FROM products)-20 ORDER BY id DESC";
$result = $mysqli->query($sql);
$arr = array();

if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_object()) {
        array_push($arr, $row);
    }
}
$str = "";
$str = json_encode($arr);
echo $str;



